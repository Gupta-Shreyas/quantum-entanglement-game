const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const DATA_FILE = path.join(__dirname,'data.json');
if(!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, JSON.stringify({total:0,correlated:0, leaderboard:[]}, null, 2));

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname,'..','frontend')));

function readData(){ return JSON.parse(fs.readFileSync(DATA_FILE,'utf8')); }
function writeData(d){ fs.writeFileSync(DATA_FILE, JSON.stringify(d,null,2)); }

function simulateOutcome(bell, basis, noise){
  let idealCorrelation = 0;
  if (basis === 'Z') {
    if (bell === 'phiPlus' || bell === 'phiMinus') idealCorrelation = 1;
    else idealCorrelation = -1;
  } else {
    if (bell === 'phiPlus' || bell === 'psiPlus') idealCorrelation = 1;
    else idealCorrelation = -1;
  }
  const flip = Math.random() < noise;
  const final = flip ? -idealCorrelation : idealCorrelation;
  return final === 1 ? 'Correlated' : 'Anti-Correlated';
}

app.get('/api/stats',(req,res)=>{
  const d = readData();
  const percent = d.total ? ((d.correlated/d.total)*100).toFixed(2) : '0.00';
  res.json({total:d.total, correlated:d.correlated, percent, leaderboard:d.leaderboard});
});

app.post('/api/measure',(req,res)=>{
  const {bell, basis, noise=0} = req.body || {};
  const outcome = simulateOutcome(bell,basis,Number(noise));

  const d = readData();
  d.total = (d.total||0) + 1;
  if(outcome === 'Correlated') d.correlated = (d.correlated||0) + 1;

  const name = (req.body.name && String(req.body.name).slice(0,20)) || 'Player';
  const score = outcome === 'Correlated' ? 10 : 1;
  d.leaderboard = d.leaderboard || [];
  d.leaderboard.unshift({name,score,date:new Date().toISOString()});
  d.leaderboard = d.leaderboard.slice(0,200);

  writeData(d);

  res.json({result:outcome, explanation:`Bell ${bell}, basis ${basis}, noise ${noise}`});
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=>console.log('Server listening on',PORT));
